# -*- coding: utf-8 *-*
__author__ = 'Victor M <viktor.manuel.garcia@gmail.com>'
__version__ = (0, 0, 1)
__maintainer__ = 'Victor M <viktor.manuel.garcia@gmail.com>'


from dylog.handlers import DynamoHandler
